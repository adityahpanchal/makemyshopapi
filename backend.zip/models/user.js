var mongoose = require("mongoose");
const crypto = require("crypto");
const uuid = require("uuid");
const { ObjectId } = mongoose.Schema;

var userSchema = new mongoose.Schema(
  {
    firstname: {
      type: String,
      required: true,
      maxlength: 32,
      trim: true
    },
    lastname: {
      type: String,
      required: true,
      maxlength: 32,
      trim: true
    },
    mobile: {
      type: Number,
      trim: true,
      required: true,
      index: {
        unique: true
      }
    },
    email:{
      type: String,
      trim: true,
    },
    isEmailVerified:{
      type: Boolean,
      required: true,
      default: false
    },
    encry_password: {
      type: String,
      required: true
    },
    salt: String,
    role: {
      type: Number,
      default: 0
    },
    deactivated: {
      type: Boolean,
      default: false,
      required: true
    },
    city: {
      type: String,
      required: true
    },
    state: {
      type: String,
      required: true
    },
    businessId: {
      type: ObjectId,
      ref: "BusinessProfile"
    },
    isAdmin: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);

userSchema
  .virtual("password")
  .set(function(password) {
    this._password = password;
    this.salt = uuid.v1();
    this.encry_password = this.securePassword(password);
  })
  .get(function() {
    return this._password;
  });

userSchema.methods = {
  autheticate: function(plainpassword) {
    return this.securePassword(plainpassword) === this.encry_password;
  },

  securePassword: function(plainpassword) {
    if (!plainpassword) return "";
    try {
      return crypto
        .createHmac("sha256", this.salt)
        .update(plainpassword)
        .digest("hex");
    } catch (err) {
      return "";
    }
  }
};

module.exports = mongoose.model("User", userSchema);
